function ll=hp2ll(p);
%function tp=hp2tp(p) 
% converts from hoop coordinates az -180=>0=>+180, el +/-90
% to (latitude,longitude) coordinates 
ll(:,1) = p(:,2);
ll(:,2) = 360-p(:,1);
