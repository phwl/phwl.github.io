function d_out=sort_ld(d_in)
% function d_out=sort_ld(d_in)
% Spak routine to sort azimuth and elevation data so that it increases 
% in elevation and increases in azimuth within each elevation cohort
% Data is sorted on the basis of the first two columns in d_in 
% SC V1.0 7/12/95

[r,c]=size(d_in);
if ((r < 2) | (c < 2))
  disp('sort_ld: malformed input list');
  return;
end

%sort on elevation
[y,i]=sort(d_in(:,2));
tmp_in=d_in(i,:);

% go through sorted list and sort azimuth within each elevation
d_out=[];
while length(tmp_in) > 0
  a=find(tmp_in(:,2)==tmp_in(1,2));
  E1=tmp_in(a,:);
  [y,i]=sort(E1(:,1));
  d_out=[d_out;E1(i,:)];
  tmp_in(a,:)=[];
end

