function draw_sp(DrawZero);
% function draw_sp(DrawZero);
% Draw a sphere and set up the plotting modes.
% In particular it clears the figure, puts it into "hold" mode 
% and sets the view to Az=0 El=0. if DrawZero > 0 then will also 
% draw a red dot at (0,0) 

hold on;
colormap([1 1 1]);
% phwl 13/4/11 set(gca,'AspectRatio',[1 1],'Visible','off');
set(gca,'Visible','off');

% draw a sphere
[x,y,z]=sphere(18);
h=mesh(x,y,z);
%set(h,'LineStyle',':')
set(h,'MarkerSize',2);
set(h,'LineWidth',0.4)
set(h,'EdgeColor',[.2 .6 1])
set(gca,'DrawMode','Fast')

% set the view to default to (0,0)
view(hp2cart([0 0]));			% look at (0,0)

% draw the 0/0 marker
if DrawZero > 0
  xyz = hp2cart([0 0]);			% convert to xyz coords
  plot3(xyz(:,1), xyz(:,2), xyz(:,3), 'r.','MarkerSize',18);
end
