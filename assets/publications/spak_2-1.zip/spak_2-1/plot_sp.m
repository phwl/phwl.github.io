function plot_sp(p, c, f);
% function plot_sp(p, c, f);
% Plot a point p in color c on the sphere. p is in hoop coordinates
% p is a matrix with [az el] being the columns and the samples as rows
% f is the size of the marker to use
% phwl V1.0  SC V2.0

xyz = hp2cart(p);		   	   % convert to xyz coords
plot3(xyz(:,1), xyz(:,2), xyz(:,3), c, 'MarkerSize',f); % plot it
