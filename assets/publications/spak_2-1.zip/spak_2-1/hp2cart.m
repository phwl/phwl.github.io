function xyz = hp2cart(p);
% function hp2cart(p);
% Return cartesian xyz coords for points p in hoop coords
% p is a matrix with [az el] being the columns and the samples as rows
% xyz is a matrix with [x y z] being the columns and the samples as rows

sc = hp2sp(p) .* pi / 180;		% convert to sph coords
xyz = [cos(sc(:,1)) .* cos(sc(:,2)), ...
	sin(sc(:,1)) .* cos(sc(:,2)), ...
	sin(sc(:,2))];
