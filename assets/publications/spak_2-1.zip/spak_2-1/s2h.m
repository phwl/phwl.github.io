function d_out=s2h(d_in);
%function d_out=s2h(d_in) 
% This Spak routine converts from spherical coordinates to hoop coordinates.
% Sperical coords are az 0=>360 and el 0=>180 az(theta???) 0 is 
% directly ahead and increases CCW and el (phi???) 0 is directly above.
% Hooop coordinates az (LHS) -180=>0=>+180 (RHS), and el +/-90.
% The routine assumes that the data is in az and el degrees in pairs of
% cols and will determine how many column pairs are in d_in.
% NB this routine always returns directly behind as azimuth +180
% 
% see also h2s
% 
% SC V1.0 7/12/95

[r,c]=size(d_in);
if rem(c,2)>0 
  disp(['s2h: Uneven number of input cols']); 
  return;
end
d_out=d_in;
for a=1:2:c
  % convert azimuth
  d_out((find(d_in(:,a)>=180)),a) = 360-d_in((find(d_in(:,a)>=180)),a);
  d_out((find(d_in(:,a)<180)),a) = -d_in((find(d_in(:,a)<180)),a);	
  % convert elevation
  d_out(:,a+1)= 90-d_in(:,a+1);
end
