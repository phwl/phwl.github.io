function r = amov_sp(mv, center);

for i=1:size(mv,1)
	r(i,:) = mv(i,:) - center;
end
