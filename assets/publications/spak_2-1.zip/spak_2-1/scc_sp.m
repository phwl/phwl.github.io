function scc = scc_sp(bigloc)
% calculate the correlation coefficient between the centroids of the
% data in bigloc

X = [];
Y = [];
sloc = sort_ld(bigloc);
[dat, sloc] = next_ld(sloc);
n = 0;
while (length(dat) > 0)
	n = n + 1;
	X = [X; drcos_sp(mean_sp(dat(:, [1 2])))];	% calc mean for source
	Y = [Y; drcos_sp(mean_sp(dat(:, [3 4])))];	% calc mean for target
	[dat, sloc] = next_ld(sloc);
end
sxy = 0;
sxx = 0;
syy = 0;
for i=1:n
	sxy = sxy + X' * Y;
	sxx = sxx + X' * X;
	syy = syy + Y' * Y;
end
scc = det(sxy) / sqrt(det(sxx) * det(syy));

