function [dat_out,b]=rfb_ld(dat,tol1,tol2);
% function [dat_out,b]=rfb_ld(dat,tol1,tol2);
% extracts the front back confusion from the dat and returns dat_out with
% F-B confusions removed. b is the index into dat, tol1 defines the area 
% around the IAA where F-B confusion are ignored (ie the estimated error 
% of localization about the inter aural axis) and tol2 is the amount by
% which target estimates are allowed to cross the midline/

b=[]; % list of data F-B confused
[r,c]=size(dat);
for i=1:r
  % is LHS
  if dat(i,1) < 0 % is LHS target
    if ((dat(i,1) > (-90-tol1)) & (dat(i,1) < (-90+tol1))) %... % target inside IAA exclusion zone
%      & ((dat(i,3) > (-90-tol1)) & (dat(i,3) < (-90+tol1)))    % AND response is inside IAA exclusion zone
        % ignore
    else
      if ((dat(i,1) < 0) & (dat(i,1) > (-90+tol1))) % target in Q1
        if ((dat(i,3) < (-90-tol1)) & (dat(i,3) > -180)) | (dat(i,3) > (180-tol2)) % response is f-b
          b=[b;i];
        end
      else % target must be in Q2
        if ((dat(i,3) > (-90+tol1)) & (dat(i,3)<tol2)) % response in R2 and is f-b
          b=[b;i];
        end
      end
    end
  else % is 0 degree or RHS target
    if ((dat(i,1) > (90-tol1)) & (dat(i,1) < (90+tol1))) %... % target inside IAA exclusion zone
%      & ((dat(i,3) > (90-tol1)) & (dat(i,3) < (90+tol1)))    % AND response is inside IAA exclusion zone
        % ignore
    else
      if ((dat(i,1) >= 0) & (dat(i,1) < (90-tol1))) % target in Q1
        if (dat(i,3) > (90+tol1) & (dat(i,3) < 180)) | (dat(i,3) < (-180+tol2)) % response is f-b
          b=[b;i];
        end
      else % target must be in Q2
        if ((dat(i,3) < (90-tol1)) & (dat(i,3)> -tol2)) % response in R2 and is f-b
          b=[b;i];
        end
      end
    end
  end
end % for loop
dat_out=dat;
dat_out(b,:)=[];

% these routines tested in part using the following matrix
% test data for front back confusion testing
% x =[
%   -45     0  -135     0
%  -135     0   -45     0
%   -90     0  -100     0
%   -10     0   175     0
%   -10     0  -175     0
%    45     0   135     0
%   135     0    45     0
%    90     0   100     0
%    10     0  -175     0
%    10     0   175     0]
