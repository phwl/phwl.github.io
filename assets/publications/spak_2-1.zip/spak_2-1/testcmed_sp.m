load bigloc.asc /ascii
% get all the data from (0,0)
t1=sel_ld(bigloc,0,0,0,0); 
% divide into 2 sets
t2=[t1(1:size(t1,1)/2,[3 4])';t1(size(t1,1)/2+1:size(t1,1),[3 4])']';
% compare medians
cmed_sp(t2)
