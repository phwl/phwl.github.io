load 'bigloc.asc' -ascii

scc_sp(bigloc)
