function [pos,list]=next_ld(d_in)
% function d_out=next_ld(d_in)
% Spak routine to select the data associated with the next target
% location in a sorted list (d_in). Returns the data (pos) and the 
% d_in list but with pos data removed.
%
% see also sort_ld, get_ld
%
% SC V1.0 7/12/95

[r,c]=size(d_in);
if ((r < 2) | (c < 2))
  %disp('next_ld: malformed input list');
  pos = [];
  list = [];
  return;
end

a=find((d_in(:,1)==d_in(1,1)) & (d_in(:,2)==d_in(1,2)));
pos=d_in(a,:);
d_in(a,:)=[];
list=d_in;
