function p = cart2hp(xyz);
% function cart2hp(p);
% Return hoop coords p for cartesian xyz
% xyz is a matrix with [x y z] being the columns and the samples as rows
% p is a matrix with [az el] being the columns and the samples as rows

az = atan2(xyz(:,2),xyz(:,1)) .* 180 / pi;
el = atan2(xyz(:,3),sqrt(xyz(:,1).^2+xyz(:,2).^2)) .* 180 / pi;
p = sp2hp([az el]);
