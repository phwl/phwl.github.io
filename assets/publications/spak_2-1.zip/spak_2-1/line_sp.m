function line_sp(v,steps,symbol);
% function line_sp(v,steps,symbol);
% this function plots a polygon composed of lines joining the points
% described by v (in hoop coordinates) on a unit sphere using the line/colour 
% specified by symbol. Each line is drawn in steps sections.

xx = [];
if (steps < 2)
	steps = 2;
end
for i=1:size(v,1)-1
	v1=hp2cart([v(i,1) v(i,2)]);
	v2=hp2cart([v(i+1,1) v(i+1,2)]);
	% calculate the angular distance
	out=cross(v2,v1);
	[tht3,phi3,r]=cart2sph(out(1),out(2),out(3));

	% Following calculation from wrldtrv2 & uses Napier's Spherical 
	% Trigonometry Cosine Rule for Sides
	% Ref: VNR Encyclopedia of Mathematics
	% draw the first point
	h=plot3(v1(1),v1(2),v1(3),'w.','MarkerSize',1,'EraseMode','none');
	% calculate the angular distance from Fisher et al
	angularDistCos=sum(v1 .* v2);
	angularDist=acos(angularDistCos)*180/pi;
	xx = [xx; v1];
	step = angularDist / steps;
	for count=1:step:angularDist-step
		% change the position of the marker in step degree steps
		rotate(h,[tht3*180/pi phi3*180/pi],step,[0 0 0]);
		xx = [xx; [get(h,'xdata') get(h,'ydata') get(h,'zdata')]];  
	end;
	% add the last point
	xx = [xx;v2];
	plot3(xx(:,1),xx(:,2),xx(:,3),symbol)
end
