function sp=hp2sp(p);
%function sp=hp2sp(p) 
% converts from hoop coordinates az -180=>0=>+180, el +/-90
% to spherical coordinates where az 0=>360 el +/-90 and r=1
% xyz is a matrix with [x y z] being the columns and the samples as rows
% p is a matrix with [az el] being the columns and the samples as rows
% sp is a matrix with [saz sel r] being the columns and the samples as rows
sp(:,2)=p(:,2);		% el unchanged
for n=1:size(p,1)
	sp(n,1) = -p(n,1);
	if (sp(n,1) < 0)
		sp(n,1) = sp(n,1) + 360;
	end
	sp(n,3) = 1;		% unit sphere
end
