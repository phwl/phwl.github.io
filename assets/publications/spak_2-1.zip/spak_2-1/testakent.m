% test Spherical directional plots of Kent distribution
load 'bigloc.asc' -ascii

[bigloc,b]=rfb_ld(bigloc,10,40);	% extract the F-B confusion errors

akent(bigloc, -90, 90, -90, 90, [0 0], 1, '(a) Front');
