function pos=get_ld(d_in,az_pos,el_pos)
% function d_out=get_ld(d_in,az_pos,el_pos)
% Spak routine to select the data associated wiht a particular azimuth and
% elevation location in a data list (d_in). Returns the data (pos)
%
% see also sort_ld, next_ld
%
% SC V1.0 7/12/95

[r,c]=size(d_in);
if ((r < 2) | (c < 2))
  disp('sort_ld: malformed input list');
  return;
end

a=find((d_in(:,1)==az_pos) & ...
       (d_in(:,2)==el_pos) ...
      );
pos=d_in(a,:);
