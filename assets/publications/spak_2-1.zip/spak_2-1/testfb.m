% test script for front-back confusion plots
load 'bigloc.asc' -ascii

% extract the F-B confusion errors
[res_loc,b]=rfb_ld(bigloc,10,40);

% NB we now remove F-B confusions rather than calculate using the resolved confusion
% this has been prompted by the existance of F-B confusion which cross the midline. 
% Although few in number they are some times relatively large (>10 deg) and its not
% clear how these should be handled

% extract them 
F_B=bigloc(b,:);
%plot the confusion matrix using and X-Y plot
clg;
% subplot(1,2,1)
plot(F_B(:,1),F_B(:,3),'r.','MarkerSize',16)
hold
plot([-180 180],[-180 180],'g')
plot(res_loc(:,1),res_loc(:,3),'b+','MarkerSize',2);
axis([-210 210 -210 210])
axis('square')
ylabel('Perceived azimuth','FontSize',14)
xlabel('Actual azimuth','FontSize',14)
set(gca,'XTick',[-180 -135 -90 -45 0 45 90 135 180]);
set(gca,'YTick',[-180 -135 -90 -45 0 45 90 135 180]);
title('FF front-back confusions (1.3%)','FontSize',12);

