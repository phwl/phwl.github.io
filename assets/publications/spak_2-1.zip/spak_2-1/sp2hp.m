function p=sp2hp(sp);
%function p=sp2hp(sp) 
% converts from spherical coordinates where az 0=>360 el +/-90.
% to hoop coordinates az -180=>0=>+180, el +/-90
% sp is a matrix with [saz sel r] being the columns and the samples as rows
% p is a matrix with [az el] being the columns and the samples as rows
p=sp;
for n=1:size(sp,1)
	p(n,1) = -sp(n,1);
	if (p(n,1) <= -180)
		p(n,1) = p(n,1) + 360;
	end
end
