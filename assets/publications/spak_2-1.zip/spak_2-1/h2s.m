function d_out=h2s(d_in);
%function d_out=h2s(d_in) 
% This Spak routine converts from hoop coordinates az (LHS)-180=>0=>+180(RHS),
% and el +/-90 to spherical coordinates where az 0=>360 and el 0=>180.
% az(theta???) 0 is directly ahead and increases CCW and el (phi???) 0 is directly above.
% The routine assumes that the data is in az and el degrees in pairs of
% cols and will determine how many column pairs are in d_in.
% Note that the hoop spec will allow both -180 and +180 degrees to specify
% the position directly behind the subject
%
% see also s2h
%
% SC V1.0 7/12/95


[r,c]=size(d_in);
if rem(c,2)>0 
  disp(['h2s: Uneven number of input cols']); 
  return;
end
d_out=d_in;
for a=1:2:c
  % convert azimuth
  d_out((find(d_in(:,a)>=0)),a) = 360-d_in((find(d_in(:,a)>=0)),a);
  d_out((find(d_in(:,a)<0)),a) = -d_in((find(d_in(:,a)<0)),a);	
  % convert elevation
  d_out((find(d_in(:,a+1)>=0)),a+1) = 90-d_in((find(d_in(:,a+1)>=0)),a+1);
  d_out((find(d_in(:,a+1)<0)),a+1) = 90+abs(d_in((find(d_in(:,a+1)<0)),a+1));
end
