% run all the test programs to verify operation of spak
figure(1)
testkent
print -dps kent.ps

figure(2)
testfb
print -dps fb.ps

figure(3)
testdl
print -dps dl.ps

testscc
