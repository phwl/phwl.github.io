function idx = clst_ld(smode, az, el, d_in)
% function [cal, cel] = clst_ld(az, el, d_in)
% find index idx to d_in which is the closest (but not equal to) 
% location (az, el). 
% If smode==0, searches for the closest az for same el
%    smode==1 for closest el with az being same
%    smode==2 az and el must be different
%    smode==3 closest larger az with el being same
%    smode==4 closest larger el with az being same
%    smode==5 closest smaller az with el being same
%    smode==6 closest smaller el with az being same

r = hp2cart([az el]);
ra = hp2cart(d_in(:,[1 2]));
for i=1:size(ra,1)
	d(i) = sum(abs(r - ra(i,:)));
	if (smode == 0)
		if ((d_in(i,1) == az) | ~(d_in(i,2) == el))
			d(i) = 360;
		end
	elseif (smode == 1)
		if (~(d_in(i,1) == az) | (d_in(i,2) == el))
			d(i) = 360;
		end
	elseif (smode == 2)
		if ((d_in(i,1) == az) | (d_in(i,2) == el))
			d(i) = 360;		% make zero matches not count
		end
	elseif (smode == 3)
		if ((d_in(i,1) <= az) | ~(d_in(i,2) == el))
			d(i) = 360;
		end
	elseif (smode == 4)
		if (~(d_in(i,1) == az) | (d_in(i,2) <= el))
			d(i) = 360;
		end
	elseif (smode == 5)	% look at -ve az
		if ((d_in(i,1) >= az) | ~(d_in(i,2) == el))
			d(i) = 360;
		end
	elseif (smode == 6)	% look at -ve el
		if (~(d_in(i,1) == az) | (d_in(i,2) >= el))
			d(i) = 360;
		end
	end
	% [i az el d_in(i,[1 2]) d(i)]
end
[y idx] = min(d);
