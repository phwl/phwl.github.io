% test script for directional line plots
load 'bigloc.asc' -ascii


% extract the F-B confusion errors
[res_loc,b]=rfb_ld(bigloc,10,40);
		
draw_sp(1);

%view(hp2cart([0 90]));
set(gca,'XLim',[-0.2 0.2])
set(gca,'YLim',[-0.23 0.23])
set(gca,'ZLim',[-0.13 0.13])

sloc = sort_ld(res_loc);
[dat, sloc] = next_ld(sloc);
while (length(dat) > 0)
	disp(' ')
        disp(dat(1,[1 2]))
	[G,kappa,beta,q,ellz,ell,ln,isk] = kent_sp(dat(:,[3 4]));
	disp(ellz)
        if (isk)
	  rln = amov_sp(ln, ln(1,:));
	  line_sp(rln([1 size(rln,1)],:), 2, 'm');	  
	  %drawnow;
        end;
        [dat, sloc] = next_ld(sloc);
end
h=text(0.1,0.25,0,'Azimuth');
h=text(0.03,0.03,0.12,'Elevation');
