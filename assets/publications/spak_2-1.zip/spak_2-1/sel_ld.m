function d_out = sel_ld(d_in,az_lo,az_hi,el_lo,el_hi);
% function d_out = sel_ld(d_in,az_lo,az_hi,el_lo,el_hi);
% Spak routine takes a four column input in d_in of az1 el1 az2 el2 
% and selects data on the basis of entries in the first two cols that are 
% in the az and el range specified (inclusive) and puts these in d_out.
%
% SC V1.0 7/12/95

[r,c]=size(d_in);
if ((az_hi > 180) | (az_lo < -180) | (el_hi > 90) | (el_lo < -90))
  disp(['sel_ld: azimuth or elevation selection out of range']);
  return;
end;

% get the index
a=find((d_in(:,1)>=az_lo) & ...
       (d_in(:,1)<=az_hi) & ...
       (d_in(:,2)>=el_lo) & ...
       (d_in(:,2)<=el_hi) ...
      );
% deliver the goods
d_out=d_in(a,:);

