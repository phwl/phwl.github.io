function Y = cmed_sp(bigloc)
% calculates a statistic for whether the medians are the same for
% two column sets of bigloc (MUST ONLY BE CALLED WITH ONE
% LOCATION!)

% get average
catvec = [];
r = size(bigloc,2)/2
for i=1:r
	catvec = [catvec; bigloc(:,[i*2-1 i*2])];
end
xmed = med_sp(catvec)
% xmed = tp2hp([72.3 338.0] .* pi / 180);
% xmed = tp2hp([0 0] .* pi / 180);
% hp2ll(xmed)

% now we can do our real loop
ysq = 0;
dat = bigloc;
for i=1:r
	n = size(dat, 1)
	x = hp2tp(rot_sp(dat(:,[i*2-1 i*2]), xmed));
	ymed = med_sp(dat(:,[i*2-1 i*2]))
	y = hp2tp(rot_sp(dat(:,[i*2-1 i*2]), ymed));

	u = [ sum(cos(x(:,2))); sum(sin(x(:,2)))] / sqrt(n)
	s11 = 1 + (1 / n) * sum(cos(2 * y(:,2)));
	s22 = 1 - (1 / n) * sum(cos(2 * y(:,2)));
	s12 = (1 / n) * sum(sin(2 * y(:,2)));
	sig = 0.5 * [ s11 s12; s12 s22 ]
	sigm1 = sig ^ (-1)
	ysq = ysq + u' * sigm1 * u

	% these test for a specific median direction
	% c11 = 1 / n * sum(cot(y(:,1)) .* (1 - cos(2 * y(:,2))) / 2);
	% c22 = 1 / n * sum(cot(y(:,1)) .* (1 + cos(2 * y(:,2))) / 2);
	% c12 = -1 / n * sum(cot(y(:,1)) .* sin(2 * y(:,2)) / 2);
	% c = [ c11 c12; c12 c22 ]
	% w = c * (sig ^ (-1)) * c
end
Y = ysq;
