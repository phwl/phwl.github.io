function [G, kappa, beta, q, ellz, ell, ln, iskent]=kent_sp(v);
% function [G, kappa, beta, q, ellz, ell, ln]=kent_sp(v);
% Returns the 3x3 matrix G where the three cols g1 g2 g3 are the centroid,
% major axis and minor axis respectively. kappa is the concentration
% parameter and beta is the ovalness parameter.  iskent is nonzero
% if it comes from a Kent distribution, otherwise it is Fisher.
%
% ellz returns the major and minor axis size for an ellipse 
% with size being the std deviation along the major and minor axes
% and ell is a set of points to plot to show the ellipse
%
% ln is a set of points to plot to show the major axis direction
%
% Inputs are the Az and El are in radian spherical coords (phi,theta)
%
% Kent's paper is J.R. Statist. Soc 1982, 44, No 1, pp. 71-80 

CONFIDENCE = 0.05;	% do our tests to 95% confidence

%% Estimate the parameters of the Kent Distribution
%% Use Data provided by Fisher Appendix B9 to test computation (Dec Inc)
%data=[176 -10;185 -6;196 -5;179 -4;186 -5;192 3;183 -1;203 -11; ...
%   193 -28;171 -14;191 -14;190 -20;187 -15;203 -26;196 -19;205 6; ...
%    182 9;190 -13;183 1;190 15;183 7;179 11;190 13;177 -10;195 11; ...
%    182 11;182 7;190 -15;183 -20;194 -7;186 -6;192 -9;192 0;180 0];

d = drcos_sp(v);						% direction cosines
n = size(d,1);
avp = hp2tp(mean_sp(v));
% tp2hp(avp)

% calc mean resultant length
s = sum(d);
r = sqrt(sum(s .* s));
rprime = r / n;                         % mean resultant length

% compute Kent parameters
T = [	sum(d(:,1) .* d(:,1)) sum(d(:,1) .* d(:,2)) sum(d(:,1) .* d(:,3)) ; 
	sum(d(:,1) .* d(:,2)) sum(d(:,2) .* d(:,2)) sum(d(:,2) .* d(:,3)) ;
	sum(d(:,1) .* d(:,3)) sum(d(:,2) .* d(:,3)) sum(d(:,3) .* d(:,3)) ];
S = T / n;
H = [	cos(avp(1))*cos(avp(2)) cos(avp(1))*sin(avp(2)) -sin(avp(1));
	-sin(avp(2))		cos(avp(2))	0;
	sin(avp(1))*cos(avp(2)) sin(avp(1))*sin(avp(2)) cos(avp(1))]';
B = H' * S * H;
psi = 0.5 * atan2(2 * B(1,2), (B(1,1) - B(2,2)));
K = [cos(psi) -sin(psi) 0; sin(psi) cos(psi) 0; 0 0 1];
G = H * K;
V = G' * S * G;
q = V(1,1) - V(2,2);
kappa = (2 - 2 * rprime - q)^(-1) + (2 - 2 * rprime + q)^(-1);
beta = 0.5 * ((2 - 2 * rprime - q)^(-1) - (2 - 2 * rprime + q)^(-1));

% Report on a few things
if kappa / beta > 2
	fprintf(1, 'Unimodal\n');
else
	fprintf(1, 'Bimodal\n');
end

% is it Fisherian or Kent?
Kstat = n * ((0.5 * kappa) ^ 2) * ...
	besseli(0.5, kappa) / besseli(2.5, kappa) * q * q;
if (Kstat > (-2 * log(CONFIDENCE)))
	fprintf('Kent dist (Kstat=%g > %g)\n', Kstat, -2*log(CONFIDENCE));
	iskent = 1;
else
	fprintf('Fisher dist (Kstat=%g <= %g)\n', Kstat, -2*log(CONFIDENCE));
	iskent = 0;
end

% rd is a rotated version of d which should be centered about hp coord (0,90)
rd = (G^(-1) * d')';
% prd = [acos(rd(:,3)) atan2(rd(:,2), rd(:,1))];	% rotated polar d
% plot_sp(tp2hp(prd), 'r*');	% draw the rotated version 

% calculate mean and std dev
uv = mean(rd);
sigv = std(rd);

% now figure out ellipse size for std deviation
ellz = sigv(1:2) / 1;
if (ellz(1) < ellz(2))
	fprintf('maj=%g < min=%g', ellz(1), ellz(2));
	error('should not happen');
end

% compute the points of the ellipse and rotate into original coordinates
PP=20;
for i=1:PP-1
   psi=i/PP*2*pi;
   x = ellz(1) * sin(psi);
   y = ellz(2) * cos(psi);
   z = abs(sqrt(1 - x*x - y*y));
   xyz = (G * [x;y;z])';	% convert to orig coords
   ell(i,:) = cart2hp(xyz);
end
ell(PP,:)=ell(1,:); % copy first to last to complete circle

% make a line and rotate
% ln(1,:) contains the centroid
for i=0:(PP+1)
   %scale = Kstat / 400;
   scale = ellz(1)*(0.5);
   x = scale*i/PP;
   y = 0;
   z = abs(sqrt(1 - x*x - y*y));
   xyz = (G * [x;y;z])';	% convert to orig coords
   ln(i + 1,:) = cart2hp(xyz);
end
