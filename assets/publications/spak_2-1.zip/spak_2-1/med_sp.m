function med = med_sp(v)
% computes the median direction of v which are in hp coords
% p is the median vector in hp coords

% get average as the starting value of p
sp = mean_sp(v);
%options = [0 1e-5];
%med = fmins('xmed_sp', p, options, [], v);
med = fminsearch(@(p) sum(acos(drcos_sp(v) * drcos_sp(p)')), sp);
