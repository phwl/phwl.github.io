% analyze localization data using Kent distribution
function akent(bigloc, az_l, az_h, el_l, el_h, vcoord, dosp, s);

frontdat = sel_ld(bigloc,az_l,az_h,el_l,el_h);
sloc = sort_ld(frontdat);
if (dosp)
	draw_sp(1);
end
view(hp2cart(vcoord));
[dat, sloc] = next_ld(sloc);
while (length(dat) > 0)
	% dat
	plot_sp(dat(1,[1 2]),'b+',6); 		% plot target location
	[G,kappa,beta,q,ellz,ell,ln,isk] = kent_sp(dat(:,[3 4]));
	if (isk)
		ecol = 'b-';
	else
		ecol = 'b:';
	end
        plot_sp(ln(1,:),'k.',8);
        line_sp([dat(1,[1,2]); ln(1,:)],5,'k-');
        line_sp(ell,2,ecol)
	drawnow;
	[dat, sloc] = next_ld(sloc);
end
h=text(1,-1.25,1,s);
set(h, 'FontSize', 10);
set(h, 'Color', 'b');
