% test Spherical directional plots of Kent distribution
load 'bigloc.asc' -ascii
dat=sel_ld(bigloc,0,0,-20,-20);
draw_sp(1);             % draw the sphere with the dot
plot_sp(dat(:,[3:4]),'w.',5);
plot_sp(dat(1,[1:2]),'b.',15);
[dat,b]=rfb_ld(dat,15,30);
[G, kappa, beta, q, ellz, ell, ln, iskent]=kent_sp(dat(:,[3,4]))
line_sp([dat(1,[1,2]); ln(1,:)],5,'w-');
line_sp(ell,2,'-');

