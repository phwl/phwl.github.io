function p = mean_sp(v)
% computes the mean direction of d which are in hp coords
% calculated using drcos_sp()
% p is the mean vector in hp coords and
% rprime is the mean resultant length

% get average
d = drcos_sp(v);						% direction cosines
s = sum(d);
r = sqrt(sum(s .* s));
s = s / r;                              % mean direction cosines
p = tp2hp(dc2tp(s));
