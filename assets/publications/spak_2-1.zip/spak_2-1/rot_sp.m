function r = rot_sp(mv, med);

med = hp2tp(med);
A = [	cos(med(1))*cos(med(2)) cos(med(1))*sin(med(2)) -sin(med(1));
	-sin(med(2))		cos(med(2))	0;
	sin(med(1))*cos(med(2)) sin(med(1))*sin(med(2)) cos(med(1))]';
for i=1:size(mv,1)
	v = A * drcos_sp(mv(i,:))';
	r(i,:) = dc2tp(v);
end
r = tp2hp(r);
